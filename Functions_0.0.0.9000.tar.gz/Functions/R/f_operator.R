#' Transform sqrt_2 and log_2
#'
#' f_operator( ) transform sqrt_2( ) and log_2( ) into functions such that :
#' 1. If input is greater than 0, then return normal output;
#' 2. If input is invalid, return an error condition object, with "invalid_input" subclass and invalid value attached.
#'
#' @param f: enter either function sqrt_2( ) or log_2( )
#'
#' @return
#' @export
#'
#' @examples
#' log_3 = f_operator(log_2)
#' set.seed(2)
#' y = lapply(runif(2,-10,10), log_3)
#'
#'# The results looks like following:
#' # [[1]]
#' #  <error/invalid input>
#' #   invalid input
#' # Backtrace:
#' #  1. base::lapply(runif(2, -10, 10), log3)
#' #   2. FUN(X[[i]], ...)
#' #   3. base::tryCatch(...)
#' #   4. base:::tryCatchList(expr, classes, parentenv, handlers)
#' #   5. base:::tryCatchOne(expr, names, parentenv, handlers[[1L]])
#' #   6. value[[3L]](cond)
#' #   7. rlang::catch_cnd(...)
#' #  13. base::force(expr)
#
#' # [[2]]
#' # [1] 1.398095
#' # y[[1]]$invalid_input
#' # [1] -6.302355

f_operator = function(f){
  force(f)
  new_f = function(x){
    if (x>0){
      f(x)
    } else{
      catch_cnd(rlang::abort(
        message = "invalid input",
        .subclass = "invalid_input",
        invalid_input = x,
        trace = NULL
      ))
    }
  }
  return(new_f)
}
