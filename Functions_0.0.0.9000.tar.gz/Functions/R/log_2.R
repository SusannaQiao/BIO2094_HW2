#' Modified log function
#'
#' Trigger errors with a negative input
#' @param x: any numeric input
#'
#' @return
#' @export
#'
#' @examples
#' log.2(-1)
#' # Error: ngative input, NA introduced!
log_2 = function(x){
  if (x<0){
    rlang::abort(message = "negative input, NA introduced!",)
  }
  else{
    log(x)
  }
}
