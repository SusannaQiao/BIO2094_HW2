#' Modified square root function
#'
#' Trigger errors with a negative input
#'
#' @param x: any numeric input
#'
#' @return
#' @export
#'
#' @examples
#' sqrt.2(-1)
#' # Error: negative input, NA introduced!
sqrt_2 = function(x){
  if (x<0){
    rlang::abort(message = "negative input, NA introduced!")
  }
  else{
    sqrt(x)
  }
}
